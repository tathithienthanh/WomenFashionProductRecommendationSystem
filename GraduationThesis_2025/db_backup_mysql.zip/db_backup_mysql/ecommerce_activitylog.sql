CREATE DATABASE  IF NOT EXISTS `ecommerce` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `ecommerce`;
-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: ecommerce
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activitylog`
--

DROP TABLE IF EXISTS `activitylog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activitylog` (
  `admin_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `activity` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `activity_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`admin_id`,`activity_time`),
  CONSTRAINT `activitylog_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`admin_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activitylog`
--

LOCK TABLES `activitylog` WRITE;
/*!40000 ALTER TABLE `activitylog` DISABLE KEYS */;
INSERT INTO `activitylog` VALUES ('C001','Xem báo cáo sản phẩm đánh giá nhiều','2025-05-04 19:11:38'),('C001','Xem báo cáo khách hàng mua nhiều','2025-05-04 19:19:55'),('C001','Xem báo cáo sản phẩm bán chạy','2025-05-04 19:24:30'),('C001','Xem báo cáo khách hàng mua nhiều','2025-05-04 19:24:35'),('C001','Xem báo cáo sản phẩm đánh giá nhiều','2025-05-04 19:25:12'),('C001','Xem báo cáo sản phẩm bán chạy','2025-05-04 19:29:21'),('C001','Xem báo cáo sản phẩm bán chạy','2025-05-04 19:31:46'),('C001','Xem báo cáo sản phẩm đánh giá nhiều','2025-05-04 19:31:51'),('C001','Xem báo cáo sản phẩm bán chạy','2025-05-04 19:49:11'),('C001','Xem báo cáo khách hàng mua nhiều','2025-05-04 20:42:02'),('C001','Xem báo cáo sản phẩm bán chạy','2025-05-04 20:42:25'),('C001','Xem báo cáo sản phẩm đánh giá nhiều','2025-05-09 09:20:19'),('C001','Xem báo cáo doanh thu','2025-05-09 09:46:28'),('C001','Xem báo cáo thống kê sản phẩm','2025-05-09 09:46:46'),('C001','Xem báo cáo sản phẩm bán chạy','2025-05-09 16:14:29'),('C001','Xem báo cáo khách hàng mua nhiều','2025-05-09 16:14:37'),('C001','Xem báo cáo sản phẩm đánh giá nhiều','2025-05-09 16:14:46'),('C001','Xem báo cáo thống kê sản phẩm','2025-05-09 16:14:54'),('C003','Thêm sản phẩm: Áo thun thoáng khí','2025-05-09 13:34:10'),('C003','Cập nhật sản phẩm: P7161','2025-05-09 13:36:33'),('C003','Xoá sản phẩm: P7161','2025-05-09 13:38:24'),('C003','Thêm sản phẩm: Sản phẩm nháp','2025-05-09 13:43:30'),('C003','Cập nhật sản phẩm: P7161','2025-05-09 13:43:57'),('C003','Xoá sản phẩm: P7161','2025-05-09 13:44:20'),('C005','Xem báo cáo khách hàng mua nhiều','2025-05-09 09:08:46'),('C005','Xem báo cáo sản phẩm bán chạy','2025-05-09 09:08:58'),('C005','Xem báo cáo khách hàng mua nhiều','2025-05-09 13:07:57'),('C005','Xem báo cáo sản phẩm đánh giá nhiều','2025-05-09 13:17:46'),('C005','Xem báo cáo thống kê sản phẩm','2025-05-09 13:17:56'),('C006','Xem báo cáo sản phẩm đánh giá nhiều','2025-05-09 09:31:40'),('C010','Xem nhật ký hoạt động của các quản trị viên','2025-05-09 14:11:00'),('C010','Xem nhật ký hoạt động của các quản trị viên','2025-05-09 14:11:07'),('C010','Xem nhật ký hoạt động của các quản trị viên','2025-05-09 14:14:22'),('C010','Xem nhật ký hoạt động của các quản trị viên','2025-05-09 14:16:33'),('C010','Xem nhật ký hoạt động của các quản trị viên','2025-05-09 14:17:03'),('C010','Xem nhật ký hoạt động của các quản trị viên','2025-05-09 14:17:08'),('C010','Xem danh sách các đơn hàng','2025-05-09 14:27:28'),('C010','Xem danh sách các đơn hàng','2025-05-09 14:27:44'),('C010','Xem nhật ký hoạt động của các quản trị viên','2025-05-09 14:32:00'),('C010','Xem danh sách các đơn hàng','2025-05-09 14:32:08'),('C010','Xem danh sách các đơn hàng','2025-05-09 14:34:08'),('C010','Xem nhật ký hoạt động của các quản trị viên','2025-05-09 14:34:54'),('C010','Xem danh sách các đơn hàng','2025-05-09 14:35:01'),('C010','Xem trạng thái đơn hàng O0046 → Đã hủy đơn','2025-05-09 14:35:41'),('C010','Xem trạng thái đơn hàng O0050 → Đã hủy đơn','2025-05-09 14:35:51'),('C010','Xem trạng thái đơn hàng O0031 → Đã hủy đơn','2025-05-09 14:38:52'),('C010','Xem trạng thái đơn hàng O0031 → Đã hủy đơn','2025-05-09 14:39:09'),('C010','Xem trạng thái đơn hàng O0002 → Đã hủy đơn','2025-05-09 14:39:42'),('C010','Xem trạng thái đơn hàng O0002 → Đang xử lý','2025-05-09 14:39:47'),('C010','Xem trạng thái đơn hàng O0002 → Đang xử lý','2025-05-09 14:39:49'),('C010','Xem trạng thái đơn hàng O0002 → Đã xác nhận','2025-05-09 14:39:54'),('C010','Xem trạng thái đơn hàng O0002 → Đã xác nhận','2025-05-09 14:39:56'),('C010','Xem trạng thái đơn hàng O0002 → Đang xử lý','2025-05-09 14:40:28'),('C010','Xem trạng thái đơn hàng O0002 → Đang xử lý','2025-05-09 14:40:30'),('C010','Xem trạng thái đơn hàng O0031 → Đã hủy đơn','2025-05-09 14:44:01'),('C010','Xem trạng thái đơn hàng O0001 → Đã hủy đơn','2025-05-09 14:44:13'),('C010','Xem trạng thái đơn hàng O0001 → Đã xác nhận','2025-05-09 14:44:18'),('C010','Xem trạng thái đơn hàng O0001 → Đã xác nhận','2025-05-09 14:44:19'),('C010','Cập nhật trạng thái đơn hàng O0031 → Chờ xác nhận','2025-05-09 14:47:00'),('C010','Xem nhật ký hoạt động của các quản trị viên','2025-05-09 16:42:00'),('C011','Xem báo cáo sản phẩm bán chạy','2025-05-09 08:30:45'),('C011','Xem báo cáo khách hàng mua nhiều','2025-05-09 08:31:49'),('C011','Xem báo cáo sản phẩm bán chạy','2025-05-09 08:59:10'),('C015','Xem báo cáo sản phẩm bán chạy','2025-05-04 20:44:08'),('C018','Xem nhật ký hoạt động của các quản trị viên','2025-05-09 14:00:25'),('C018','Xem nhật ký hoạt động của các quản trị viên','2025-05-09 14:01:14'),('C020','Xem báo cáo doanh thu','2025-05-09 09:57:48'),('C020','Xem báo cáo thống kê sản phẩm','2025-05-09 09:58:56'),('C020','Xem báo cáo thống kê sản phẩm','2025-05-09 10:02:27'),('C023','Xem báo cáo sản phẩm bán chạy','2025-05-04 20:53:58'),('C023','Xem báo cáo khách hàng mua nhiều','2025-05-04 20:54:27'),('C030','Xem báo cáo thống kê sản phẩm','2025-05-09 10:05:11'),('C030','Xem báo cáo doanh thu','2025-05-09 10:06:16'),('C030','Xem báo cáo khách hàng mua nhiều','2025-05-09 10:06:24'),('C030','Xem báo cáo sản phẩm bán chạy','2025-05-09 10:06:30'),('C030','Xem báo cáo sản phẩm đánh giá nhiều','2025-05-09 10:06:38'),('C039','Xem báo cáo sản phẩm bán chạy','2025-05-09 09:05:07'),('C040','Xem báo cáo thống kê sản phẩm','2025-05-09 11:38:49'),('C044','Xem báo cáo sản phẩm đánh giá nhiều','2025-05-04 20:58:53'),('C044','Xem báo cáo sản phẩm bán chạy','2025-05-04 20:59:18'),('C044','Xem báo cáo sản phẩm bán chạy','2025-05-04 21:03:44'),('C044','Xem báo cáo sản phẩm bán chạy','2025-05-04 21:05:44'),('C044','Xem báo cáo sản phẩm bán chạy','2025-05-04 21:06:30'),('C044','Xem báo cáo sản phẩm bán chạy','2025-05-04 21:08:44'),('C044','Xem báo cáo sản phẩm bán chạy','2025-05-04 21:09:32'),('C044','Xem báo cáo sản phẩm bán chạy','2025-05-04 21:11:58'),('C044','Xem báo cáo sản phẩm bán chạy','2025-05-04 21:14:44'),('C044','Xem báo cáo sản phẩm bán chạy','2025-05-09 09:11:17'),('C044','Xem báo cáo sản phẩm đánh giá nhiều','2025-05-09 09:11:32'),('C044','Xem báo cáo khách hàng mua nhiều','2025-05-09 09:19:20'),('C044','Xem báo cáo sản phẩm đánh giá nhiều','2025-05-09 09:34:57'),('C062','Xem báo cáo sản phẩm đánh giá nhiều','2025-05-04 19:43:02');
/*!40000 ALTER TABLE `activitylog` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-10 10:24:23
