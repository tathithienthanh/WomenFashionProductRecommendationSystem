CREATE DATABASE  IF NOT EXISTS `ecommerce` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `ecommerce`;
-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: ecommerce
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `admin_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES ('C001','Vũ','Công Linh','vu.linh1@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C002','Đào','Công Giang','dao.giang2@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C003','Trần','Minh Dũng','tran.dung3@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C004','Trương','Văn Hương','truong.huong4@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C005','Đặng','Công Linh','dang.linh5@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C006','Huỳnh','Minh Chi','huynh.chi6@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C007','Đào','Ngọc Linh','dao.linh7@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C008','Nguyễn','Hữu An','nguyen.an8@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C009','Bùi','Kim Linh','bui.linh9@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C010','Lê','Minh Nam','le.nam10@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C011','Đào','Công An','dao.an11@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C012','Phan','Đức Hương','phan.huong12@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C013','Võ','Minh Phương','vo.phuong13@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C014','Đỗ','Công Nam','do.nam14@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C015','Trương','Minh Nam','truong.nam15@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C016','Võ','Công Chi','vo.chi16@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C017','Huỳnh','Đức Giang','huynh.giang17@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C018','Đinh','Văn Bình','dinh.binh18@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C019','Phan','Hữu Bình','phan.binh19@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C020','Võ','Thành Dũng','vo.dung20@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C021','Đào','Đức Nam','dao.nam21@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C022','Nguyễn','Thanh Chi','nguyen.chi22@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C023','Vũ','Thanh Giang','vu.giang23@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C024','Đặng','Thành Chi','dang.chi24@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C025','Nguyễn','Công Chi','nguyen.chi25@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C026','Đào','Văn An','dao.an26@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C027','Trương','Văn Hương','truong.huong27@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C028','Đào','Kim Chi','dao.chi28@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C029','Dương','Minh An','duong.an29@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C030','Mai','Ngọc Giang','mai.giang30@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C031','Đào','Kim An','dao.an31@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C032','Đào','Kim Chi','dao.chi32@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C033','Trần','Thị Giang','tran.giang33@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C034','Mai','Đức An','mai.an34@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C035','Lê','Thành Linh','le.linh35@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C036','Lý','Văn Phương','ly.phuong36@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C037','Hoàng','Thành Giang','hoang.giang37@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C038','Võ','Công Linh','vo.linh38@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C039','Mai','Minh An','mai.an39@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C040','Hoàng','Ngọc Chi','hoang.chi40@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C041','Đặng','Thanh Chi','dang.chi41@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C042','Đinh','Văn Hương','dinh.huong42@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C043','Hồ','Văn Dũng','ho.dung43@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C044','Mai','Đức Phương','mai.phuong44@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C045','Ngô','Thị Bình','ngo.binh45@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C046','Phan','Kim Khánh','phan.khanh46@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C047','Đỗ','Kim Dũng','do.dung47@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C048','Huỳnh','Thanh Giang','huynh.giang48@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C049','Nguyễn','Văn Hương','nguyen.huong49@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C050','Phan','Hữu Chi','phan.chi50@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C051','Hoàng','Minh Linh','hoang.linh51@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C052','Vũ','Hữu Giang','vu.giang52@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C053','Vũ','Minh Dũng','vu.dung53@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C054','Hoàng','Đức Khánh','hoang.khanh54@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C055','Hoàng','Hữu Hương','hoang.huong55@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C056','Lý','Văn Linh','ly.linh56@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C057','Nguyễn','Thành Nam','nguyen.nam57@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C058','Đỗ','Ngọc Phương','do.phuong58@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C059','Vũ','Thành An','vu.an59@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C060','Huỳnh','Thành Chi','huynh.chi60@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C061','Hồ','Thanh Khánh','ho.khanh61@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C062','Lý','Công Giang','ly.giang62@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C063','Đỗ','Đức Khánh','do.khanh63@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C064','Phạm','Thanh An','pham.an64@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C065','Dương','Kim Khánh','duong.khanh65@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C066','Mai','Kim Chi','mai.chi66@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C067','Đặng','Hữu Khánh','dang.khanh67@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C068','Trần','Kim Chi','tran.chi68@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C069','Bùi','Minh Giang','bui.giang69@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C070','Lý','Thành Nam','ly.nam70@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C071','Phạm','Văn Hương','pham.huong71@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C072','Phan','Ngọc Chi','phan.chi72@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C073','Mai','Văn Khánh','mai.khanh73@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C074','Huỳnh','Văn Phương','huynh.phuong74@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C075','Đào','Thị Hương','dao.huong75@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C076','Trương','Ngọc Khánh','truong.khanh76@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C077','Nguyễn','Thanh Dũng','nguyen.dung77@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C078','Nguyễn','Hữu Hương','nguyen.huong78@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C079','Dương','Thanh Linh','duong.linh79@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C080','Ngô','Kim An','ngo.an80@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C081','Phan','Ngọc Hương','phan.huong81@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C082','Dương','Hữu An','duong.an82@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C083','Trương','Thanh Phương','truong.phuong83@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C084','Đinh','Hữu Bình','dinh.binh84@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C085','Trương','Công Phương','truong.phuong85@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C086','Trương','Văn Giang','truong.giang86@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C087','Mai','Thanh Khánh','mai.khanh87@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C088','Phạm','Ngọc Giang','pham.giang88@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C089','Nguyễn','Văn Linh','nguyen.linh89@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C090','Phan','Hữu Hương','phan.huong90@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C091','Đào','Ngọc Phương','dao.phuong91@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C092','Phan','Đức An','phan.an92@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C093','Đỗ','Minh An','do.an93@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C094','Ngô','Ngọc Chi','ngo.chi94@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C095','Nguyễn','Thành Chi','nguyen.chi95@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C096','Trương','Văn An','truong.an96@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C097','Lý','Văn Nam','ly.nam97@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C098','Nguyễn','Minh Chi','nguyen.chi98@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C099','Ngô','Đức Linh','ngo.linh99@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72'),('C100','Võ','Công Linh','vo.linh100@gmail.com','231ecc7d178da5f22983bc579599396d6c139a457987ae1ee0026d88432d6a72');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `secure_admin_password_before_insert` BEFORE INSERT ON `admin` FOR EACH ROW BEGIN
    CALL ValidatePassword(NEW.password);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `check_admin_email_before_insert` BEFORE INSERT ON `admin` FOR EACH ROW BEGIN
    IF NEW.email NOT REGEXP '^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}$' THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Email không hợp lệ';
    END IF;
    
    IF EXISTS (SELECT 1 FROM admin WHERE email = NEW.email) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Email đã tồn tại trong hệ thống';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `secure_admin_password_before_update` BEFORE UPDATE ON `admin` FOR EACH ROW BEGIN
    IF NEW.password <> OLD.password THEN
        CALL ValidatePassword(NEW.password);
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `check_admin_email_before_update` BEFORE UPDATE ON `admin` FOR EACH ROW BEGIN
    IF NEW.email NOT REGEXP '^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}$' THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Email không hợp lệ';
    END IF;
    
    IF NEW.email <> OLD.email AND EXISTS (SELECT 1 FROM admin WHERE email = NEW.email) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Email đã tồn tại trong hệ thống';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-10 10:24:24
