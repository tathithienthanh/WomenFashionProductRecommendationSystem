CREATE DATABASE  IF NOT EXISTS `ecommerce` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `ecommerce`;
-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: ecommerce
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `customer_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES ('C001','Phạm','Ngọc Khánh','pham.khanh1@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654321','2 Đường số 1, Quận 2, TP.HCM'),('C002','Đinh','Thanh Dũng','dinh.dung2@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654322','3 Đường số 2, Quận 3, TP.HCM'),('C003','Huỳnh','Ngọc Linh','huynh.linh3@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654323','4 Đường số 3, Quận 4, TP.HCM'),('C004','Đặng','Kim Phương','dang.phuong4@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654324','5 Đường số 4, Quận 5, TP.HCM'),('C005','Huỳnh','Thành Nam','huynh.nam5@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654325','6 Đường số 5, Quận 1, TP.HCM'),('C006','Lý','Thanh Bình','ly.binh6@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654326','7 Đường số 6, Quận 2, TP.HCM'),('C007','Phạm','Kim Dũng','pham.dung7@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654327','8 Đường số 7, Quận 3, TP.HCM'),('C008','Phạm','Đức Giang','pham.giang8@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654328','9 Đường số 8, Quận 4, TP.HCM'),('C009','Hoàng','Hữu Chi','hoang.chi9@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654329','10 Đường số 9, Quận 5, TP.HCM'),('C010','Phan','Thanh Chi','phan.chi10@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654320','11 Đường số 10, Quận 1, TP.HCM'),('C011','Huỳnh','Minh Hương','huynh.huong11@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654321','12 Đường số 11, Quận 2, TP.HCM'),('C012','Đinh','Minh Dũng','dinh.dung12@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654322','13 Đường số 12, Quận 3, TP.HCM'),('C013','Hoàng','Công Phương','hoang.phuong13@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654323','14 Đường số 13, Quận 4, TP.HCM'),('C014','Mai','Đức Giang','mai.giang14@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654324','15 Đường số 14, Quận 5, TP.HCM'),('C015','Mai','Thị Phương','mai.phuong15@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654325','16 Đường số 15, Quận 1, TP.HCM'),('C016','Lý','Thị Khánh','ly.khanh16@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654326','17 Đường số 16, Quận 2, TP.HCM'),('C017','Lê','Thành Phương','le.phuong17@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654327','18 Đường số 17, Quận 3, TP.HCM'),('C018','Vũ','Ngọc Chi','vu.chi18@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654328','19 Đường số 18, Quận 4, TP.HCM'),('C019','Hồ','Ngọc An','ho.an19@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654329','20 Đường số 19, Quận 5, TP.HCM'),('C020','Ngô','Đức Khánh','ngo.khanh20@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654320','21 Đường số 20, Quận 1, TP.HCM'),('C021','Trương','Ngọc Bình','truong.binh21@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654321','22 Đường số 21, Quận 2, TP.HCM'),('C022','Mai','Đức Linh','mai.linh22@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654322','23 Đường số 22, Quận 3, TP.HCM'),('C023','Phạm','Kim Hương','pham.huong23@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654323','24 Đường số 23, Quận 4, TP.HCM'),('C024','Hồ','Hữu Bình','ho.binh24@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654324','25 Đường số 24, Quận 5, TP.HCM'),('C025','Vũ','Hữu An','vu.an25@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654325','26 Đường số 25, Quận 1, TP.HCM'),('C026','Võ','Ngọc Nam','vo.nam26@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654326','27 Đường số 26, Quận 2, TP.HCM'),('C027','Lý','Hữu Khánh','ly.khanh27@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654327','28 Đường số 27, Quận 3, TP.HCM'),('C028','Lê','Kim Chi','le.chi28@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654328','29 Đường số 28, Quận 4, TP.HCM'),('C029','Đỗ','Thị An','do.an29@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654329','30 Đường số 29, Quận 5, TP.HCM'),('C030','Hồ','Kim Khánh','ho.khanh30@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654320','31 Đường số 30, Quận 1, TP.HCM'),('C031','Huỳnh','Kim Bình','huynh.binh31@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654321','32 Đường số 31, Quận 2, TP.HCM'),('C032','Trần','Văn Nam','tran.nam32@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654322','33 Đường số 32, Quận 3, TP.HCM'),('C033','Đào','Văn Khánh','dao.khanh33@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654323','34 Đường số 33, Quận 4, TP.HCM'),('C034','Huỳnh','Thành Dũng','huynh.dung34@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654324','35 Đường số 34, Quận 5, TP.HCM'),('C035','Mai','Thanh Bình','mai.binh35@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654325','36 Đường số 35, Quận 1, TP.HCM'),('C036','Hoàng','Văn Nam','hoang.nam36@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654326','37 Đường số 36, Quận 2, TP.HCM'),('C037','Huỳnh','Kim Phương','huynh.phuong37@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654327','38 Đường số 37, Quận 3, TP.HCM'),('C038','Lý','Công Bình','ly.binh38@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654328','39 Đường số 38, Quận 4, TP.HCM'),('C039','Ngô','Hữu Giang','ngo.giang39@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654329','40 Đường số 39, Quận 5, TP.HCM'),('C040','Đỗ','Thanh Dũng','do.dung40@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654320','41 Đường số 40, Quận 1, TP.HCM'),('C041','Hồ','Ngọc Khánh','ho.khanh41@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654321','42 Đường số 41, Quận 2, TP.HCM'),('C042','Đỗ','Thành Khánh','do.khanh42@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654322','43 Đường số 42, Quận 3, TP.HCM'),('C043','Nguyễn','Công Bình','nguyen.binh43@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654323','44 Đường số 43, Quận 4, TP.HCM'),('C044','Đỗ','Thanh Bình','do.binh44@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654324','45 Đường số 44, Quận 5, TP.HCM'),('C045','Lý','Thành Dũng','ly.dung45@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654325','46 Đường số 45, Quận 1, TP.HCM'),('C046','Hoàng','Công Giang','hoang.giang46@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654326','47 Đường số 46, Quận 2, TP.HCM'),('C047','Trương','Đức Dũng','truong.dung47@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654327','48 Đường số 47, Quận 3, TP.HCM'),('C048','Trương','Thanh Phương','truong.phuong48@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654328','49 Đường số 48, Quận 4, TP.HCM'),('C049','Hoàng','Kim Linh','hoang.linh49@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654329','50 Đường số 49, Quận 5, TP.HCM'),('C050','Mai','Văn Chi','mai.chi50@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654320','51 Đường số 50, Quận 1, TP.HCM'),('C051','Đỗ','Thị Hương','do.huong51@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654321','52 Đường số 51, Quận 2, TP.HCM'),('C052','Bùi','Đức Khánh','bui.khanh52@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654322','53 Đường số 52, Quận 3, TP.HCM'),('C053','Hoàng','Minh Chi','hoang.chi53@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654323','54 Đường số 53, Quận 4, TP.HCM'),('C054','Hoàng','Hữu Linh','hoang.linh54@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654324','55 Đường số 54, Quận 5, TP.HCM'),('C055','Mai','Văn An','mai.an55@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654325','56 Đường số 55, Quận 1, TP.HCM'),('C056','Đinh','Đức Giang','dinh.giang56@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654326','57 Đường số 56, Quận 2, TP.HCM'),('C057','Dương','Công An','duong.an57@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654327','58 Đường số 57, Quận 3, TP.HCM'),('C058','Đào','Ngọc Dũng','dao.dung58@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654328','59 Đường số 58, Quận 4, TP.HCM'),('C059','Mai','Hữu An','mai.an59@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654329','60 Đường số 59, Quận 5, TP.HCM'),('C060','Hoàng','Ngọc Linh','hoang.linh60@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654320','61 Đường số 60, Quận 1, TP.HCM'),('C061','Huỳnh','Đức Chi','huynh.chi61@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654321','62 Đường số 61, Quận 2, TP.HCM'),('C062','Lý','Thanh Khánh','ly.khanh62@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654322','63 Đường số 62, Quận 3, TP.HCM'),('C063','Ngô','Thành Nam','ngo.nam63@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654323','64 Đường số 63, Quận 4, TP.HCM'),('C064','Lê','Ngọc Dũng','le.dung64@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654324','65 Đường số 64, Quận 5, TP.HCM'),('C065','Lê','Minh Nam','le.nam65@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654325','66 Đường số 65, Quận 1, TP.HCM'),('C066','Đào','Minh Phương','dao.phuong66@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654326','67 Đường số 66, Quận 2, TP.HCM'),('C067','Trương','Thanh Chi','truong.chi67@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654327','68 Đường số 67, Quận 3, TP.HCM'),('C068','Dương','Ngọc Dũng','duong.dung68@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654328','69 Đường số 68, Quận 4, TP.HCM'),('C069','Đỗ','Ngọc Khánh','do.khanh69@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654329','70 Đường số 69, Quận 5, TP.HCM'),('C070','Dương','Đức Giang','duong.giang70@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654320','71 Đường số 70, Quận 1, TP.HCM'),('C071','Đinh','Thị Chi','dinh.chi71@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654321','72 Đường số 71, Quận 2, TP.HCM'),('C072','Dương','Ngọc Giang','duong.giang72@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654322','73 Đường số 72, Quận 3, TP.HCM'),('C073','Ngô','Công Nam','ngo.nam73@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654323','74 Đường số 73, Quận 4, TP.HCM'),('C074','Hồ','Hữu Hương','ho.huong74@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654324','75 Đường số 74, Quận 5, TP.HCM'),('C075','Nguyễn','Văn Bình','nguyen.binh75@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654325','76 Đường số 75, Quận 1, TP.HCM'),('C076','Trương','Hữu Nam','truong.nam76@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654326','77 Đường số 76, Quận 2, TP.HCM'),('C077','Hồ','Kim Khánh','ho.khanh77@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654327','78 Đường số 77, Quận 3, TP.HCM'),('C078','Đỗ','Thành Dũng','do.dung78@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654328','79 Đường số 78, Quận 4, TP.HCM'),('C079','Dương','Công Linh','duong.linh79@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654329','80 Đường số 79, Quận 5, TP.HCM'),('C080','Lý','Thành Khánh','ly.khanh80@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654320','81 Đường số 80, Quận 1, TP.HCM'),('C081','Mai','Đức An','mai.an81@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654321','82 Đường số 81, Quận 2, TP.HCM'),('C082','Mai','Văn Linh','mai.linh82@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654322','83 Đường số 82, Quận 3, TP.HCM'),('C083','Ngô','Hữu Dũng','ngo.dung83@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654323','84 Đường số 83, Quận 4, TP.HCM'),('C084','Lê','Đức Bình','le.binh84@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654324','85 Đường số 84, Quận 5, TP.HCM'),('C085','Lê','Công Chi','le.chi85@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654325','86 Đường số 85, Quận 1, TP.HCM'),('C086','Đặng','Thành Dũng','dang.dung86@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654326','87 Đường số 86, Quận 2, TP.HCM'),('C087','Ngô','Thành Phương','ngo.phuong87@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654327','88 Đường số 87, Quận 3, TP.HCM'),('C088','Nguyễn','Ngọc Chi','nguyen.chi88@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654328','89 Đường số 88, Quận 4, TP.HCM'),('C089','Lê','Hữu Linh','le.linh89@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654329','90 Đường số 89, Quận 5, TP.HCM'),('C090','Trần','Công Hương','tran.huong90@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654320','91 Đường số 90, Quận 1, TP.HCM'),('C091','Bùi','Đức An','bui.an91@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654321','92 Đường số 91, Quận 2, TP.HCM'),('C092','Trần','Minh An','tran.an92@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654322','93 Đường số 92, Quận 3, TP.HCM'),('C093','Lý','Thanh Phương','ly.phuong93@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654323','94 Đường số 93, Quận 4, TP.HCM'),('C094','Lý','Thành Dũng','ly.dung94@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654324','95 Đường số 94, Quận 5, TP.HCM'),('C095','Ngô','Ngọc Giang','ngo.giang95@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654325','96 Đường số 95, Quận 1, TP.HCM'),('C096','Hoàng','Hữu Khánh','hoang.khanh96@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654326','97 Đường số 96, Quận 2, TP.HCM'),('C097','Huỳnh','Ngọc Nam','huynh.nam97@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654327','98 Đường số 97, Quận 3, TP.HCM'),('C098','Đỗ','Đức Phương','do.phuong98@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654328','99 Đường số 98, Quận 4, TP.HCM'),('C099','Mai','Văn Chi','mai.chi99@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654329','100 Đường số 99, Quận 5, TP.HCM'),('C100','Ngô','Công Phương','ngo.phuong100@gmail.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','987654320','101 Đường số 100, Quận 1, TP.HCM'),('C101','Naruto','Uzumaki','nanadaimehokage@konoha.com','4c68cf8348d0f82496359eb67539483db3a6fd63b9590a99ba0fbe905ebe0d58','02178462367','konoha');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `secure_customer_password_before_insert` BEFORE INSERT ON `customer` FOR EACH ROW BEGIN
    CALL ValidatePassword(NEW.password);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `check_customer_email_before_insert` BEFORE INSERT ON `customer` FOR EACH ROW BEGIN
    IF NEW.email NOT REGEXP '^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}$' THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Email khách hàng không hợp lệ';
    END IF;
    
    IF EXISTS (SELECT 1 FROM Customer WHERE email = NEW.email) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Email đã tồn tại trong hệ thống';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `secure_customer_password_before_update` BEFORE UPDATE ON `customer` FOR EACH ROW BEGIN
    IF NEW.password <> OLD.password THEN
        CALL ValidatePassword(NEW.password);
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `check_customer_email_before_update` BEFORE UPDATE ON `customer` FOR EACH ROW BEGIN
    IF NEW.email NOT REGEXP '^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}$' THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Email khách hàng không hợp lệ';
    END IF;
    
    IF NEW.email <> OLD.email AND EXISTS (SELECT 1 FROM Customer WHERE email = NEW.email) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Email đã tồn tại trong hệ thống';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-10 10:24:23
