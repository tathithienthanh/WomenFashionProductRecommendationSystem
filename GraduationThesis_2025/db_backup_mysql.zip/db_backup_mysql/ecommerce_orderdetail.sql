CREATE DATABASE  IF NOT EXISTS `ecommerce` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `ecommerce`;
-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: ecommerce
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orderdetail`
--

DROP TABLE IF EXISTS `orderdetail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orderdetail` (
  `order_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `unit_price` double NOT NULL,
  `discount` float DEFAULT NULL,
  PRIMARY KEY (`order_id`,`product_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `orderdetail_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE,
  CONSTRAINT `orderdetail_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderdetail`
--

LOCK TABLES `orderdetail` WRITE;
/*!40000 ALTER TABLE `orderdetail` DISABLE KEYS */;
INSERT INTO `orderdetail` VALUES ('O0001','P7090',2,28620.000000000004,0.48),('O0002','P1592',2,63800.00000000001,0.38),('O0002','P4009',2,196560.00000000003,0.32),('O0002','P6536',2,34720,0.14),('O0003','P3493',3,162519.99999999997,0.25),('O0004','P1914',2,84999.99999999999,0.27),('O0005','P1372',2,28290.000000000004,0.26),('O0006','P2743',3,48960,0.31),('O0006','P3801',1,280000,0.13),('O0006','P4847',1,239870,0.22),('O0007','P4982',1,29670.000000000004,0.35),('O0008','P2636',2,34500,0.08),('O0008','P3751',3,58739.99999999999,0.4),('O0009','P6962',1,94640.00000000001,0.05),('O0010','P5705',2,34300,0.01),('O0011','P0971',2,225059.99999999997,0.36),('O0011','P2915',3,434830.00000000006,0.45),('O0011','P4521',1,260000,0.18),('O0012','P5665',2,83850,0.41),('O0013','P4211',3,201600.00000000003,0.05),('O0014','P3079',3,88550,0.27),('O0015','P6873',3,75000,0.35),('O0016','P0533',1,60030,0.2),('O0017','P2192',2,104160.00000000001,0.18),('O0018','P2450',1,62309.99999999999,0.09),('O0018','P7104',2,62410,0.19),('O0019','P0084',3,31920.000000000004,0.11),('O0019','P5198',3,171500,0.09),('O0019','P6167',1,69440,0.36),('O0020','P6188',1,54000,0.39),('O0021','P0238',2,73600,0.03),('O0021','P3574',2,84270,0.31),('O0022','P0528',2,90160,0.26),('O0023','P4635',2,30259.999999999996,0.45),('O0023','P6051',1,34500,0.26),('O0024','P2786',2,520000,0.01),('O0025','P3349',1,84500,0.24),('O0026','P4842',2,19110,0.48),('O0026','P5593',2,108899.99999999999,0.27),('O0027','P3393',1,41870,0.25),('O0028','P5258',2,77840.00000000001,0.43),('O0029','P5021',2,289000,0.3),('O0030','P4032',2,117600.00000000001,0.4),('O0031','P2212',1,145080,0.11),('O0031','P6681',2,61380,0.25),('O0032','P0194',2,147900,0.42),('O0033','P1764',3,59679.00000000001,0.15),('O0033','P5877',3,97350.00000000001,0.4),('O0034','P3834',1,220000,0.16),('O0035','P0403',3,171254,0.36),('O0035','P2155',3,145340,0.15),('O0035','P5100',3,579420.0000000001,0.49),('O0036','P3635',3,97865.6,0.39),('O0036','P5020',1,41870,0.23),('O0036','P5185',2,38939.99999999999,0.21),('O0037','P3385',3,123750,0.39),('O0038','P1555',3,102300,0.42),('O0039','P4259',2,332095.85,0.44),('O0040','P4611',3,67760,0.01),('O0041','P0881',2,153678.84,0.43),('O0041','P6353',2,29219,0.02),('O0042','P1266',3,43680.00000000001,0.13),('O0042','P5889',3,32370,0.32),('O0043','P0749',1,199402.72,0.02),('O0044','P0033',1,59500,0.31),('O0044','P1625',1,114400,0.14),('O0045','P2549',3,560900,0.13),('O0045','P3302',3,22420,0.38),('O0045','P6814',3,62540.00000000001,0.44),('O0046','P5518',1,103750,0.12),('O0047','P6895',1,108822.59999999999,0.02),('O0048','P0877',1,93440,0.39),('O0048','P3450',2,650000,0.01),('O0049','P3583',1,65339.99999999999,0.09),('O0050','P6293',2,499500,0.22);
/*!40000 ALTER TABLE `orderdetail` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `update_orderdetail_unitprice_before_insert` BEFORE INSERT ON `orderdetail` FOR EACH ROW BEGIN
    DECLARE product_price DOUBLE;
    DECLARE product_discount DOUBLE;
    
    SELECT price, IFNULL(discount, 0) INTO product_price, product_discount
    FROM Product
    WHERE product_id = NEW.product_id;
    
    SET NEW.unit_price = product_price * (1 - product_discount);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `check_product_quantity_before_insert` BEFORE INSERT ON `orderdetail` FOR EACH ROW BEGIN
    DECLARE available_qty INT;
    
    SELECT quantity INTO available_qty 
    FROM Product WHERE product_id = NEW.product_id;
    
    IF available_qty < NEW.quantity THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Sản phẩm không đủ số lượng tồn kho';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `update_order_total_after_insert` AFTER INSERT ON `orderdetail` FOR EACH ROW BEGIN
    UPDATE Orders o
    SET o.total_price = (
        SELECT SUM(unit_price * quantity * (1 - IFNULL(discount, 0)))
        FROM OrderDetail
        WHERE order_id = NEW.order_id
    )
    WHERE o.order_id = NEW.order_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `update_order_total_after_update` AFTER UPDATE ON `orderdetail` FOR EACH ROW BEGIN
    UPDATE Orders o
    SET o.total_price = (
        SELECT SUM(unit_price * quantity * (1 - IFNULL(discount, 0)))
        FROM OrderDetail
        WHERE order_id = NEW.order_id
    )
    WHERE o.order_id = NEW.order_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `update_order_total_after_delete` AFTER DELETE ON `orderdetail` FOR EACH ROW BEGIN
    UPDATE Orders o
    SET o.total_price = (
        SELECT IFNULL(SUM(unit_price * quantity * (1 - IFNULL(discount, 0))), 0)
        FROM OrderDetail
        WHERE order_id = OLD.order_id
    )
    WHERE o.order_id = OLD.order_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-10 10:24:24
