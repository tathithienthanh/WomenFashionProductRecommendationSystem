CREATE DATABASE  IF NOT EXISTS `ecommerce` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `ecommerce`;
-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: ecommerce
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `order_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `shipped_date` timestamp NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_price` double DEFAULT NULL,
  `payment` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`order_id`),
  KEY `customer_id` (`customer_id`),
  KEY `order_status` (`order_status`),
  KEY `payment` (`payment`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`) ON DELETE CASCADE,
  CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`order_status`) REFERENCES `orderstatus` (`status_id`),
  CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`payment`) REFERENCES `payment` (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES ('O0001','C062','CONFIRMED','2024-12-02 14:06:47','2024-12-03 14:06:47','195 Đường số 3, Quận 6, TP.HCM',NULL,29764.80061411858,'CREDIT_CARD'),('O0002','C007','PENDING','2025-04-10 14:06:47',NULL,'228 Đường số 3, Quận 6, TP.HCM',NULL,406152.00337886816,'CREDIT_CARD'),('O0003','C016','PROCESSING','2024-06-30 14:06:47',NULL,'53 Đường số 1, Quận 7, TP.HCM',NULL,365669.9999999999,'BANK_TRANSFER'),('O0004','C090','PROCESSING','2024-10-12 14:06:47',NULL,'72 Đường số 8, Quận 2, TP.HCM',NULL,124099.99817609786,'E_WALLET'),('O0005','C090','SHIPPED','2024-07-26 14:06:47','2024-07-30 14:06:47','217 Đường số 10, Quận 6, TP.HCM',NULL,41869.200539588935,'COD'),('O0006','C033','SHIPPED','2024-09-28 14:06:47','2024-09-29 14:06:47','206 Đường số 1, Quận 10, TP.HCM',NULL,532045.8012709022,'CREDIT_CARD'),('O0007','C029','PROCESSING','2025-04-18 14:06:47',NULL,'216 Đường số 7, Quận 8, TP.HCM',NULL,19285.500176846985,'BANK_TRANSFER'),('O0008','C052','PENDING','2024-10-09 14:06:47',NULL,'246 Đường số 9, Quận 9, TP.HCM',NULL,169211.99907302856,'COD'),('O0009','C017','SHIPPED','2024-11-08 14:06:47','2024-11-11 14:06:47','29 Đường số 8, Quận 5, TP.HCM',NULL,89907.99992948772,'CREDIT_CARD'),('O0010','C033','PENDING','2024-08-06 14:06:47',NULL,'41 Đường số 6, Quận 5, TP.HCM',NULL,67914.0000153333,'CREDIT_CARD'),('O0011','C074','CANCELLED','2025-03-14 14:06:47',NULL,'45 Đường số 8, Quận 8, TP.HCM',NULL,1218746.3072520494,'E_WALLET'),('O0012','C095','CONFIRMED','2025-03-30 14:06:47',NULL,'76 Đường số 3, Quận 11, TP.HCM',NULL,98943.00059974194,'BANK_TRANSFER'),('O0013','C081','PENDING','2024-06-26 14:06:47',NULL,'15 Đường số 10, Quận 2, TP.HCM',NULL,574559.999549389,'E_WALLET'),('O0014','C008','CONFIRMED','2024-05-31 14:06:47',NULL,'54 Đường số 7, Quận 4, TP.HCM',NULL,193924.4971498847,'E_WALLET'),('O0015','C012','SHIPPED','2024-07-09 14:06:47','2024-07-12 14:06:47','122 Đường số 2, Quận 6, TP.HCM',NULL,146250.0013411045,'BANK_TRANSFER'),('O0016','C074','PENDING','2025-01-06 14:06:47',NULL,'106 Đường số 9, Quận 11, TP.HCM',NULL,48023.99982109666,'E_WALLET'),('O0017','C034','SHIPPED','2024-10-14 14:06:47','2024-10-21 14:06:47','136 Đường số 10, Quận 4, TP.HCM',NULL,170822.39850997928,'COD'),('O0018','C004','CONFIRMED','2024-05-22 14:06:47',NULL,'217 Đường số 1, Quận 8, TP.HCM',NULL,157806.30007475615,'BANK_TRANSFER'),('O0019','C082','PENDING','2024-09-12 14:06:47',NULL,'169 Đường số 3, Quận 9, TP.HCM',NULL,597862.9972237349,'CREDIT_CARD'),('O0020','C061','PROCESSING','2024-06-28 14:06:47',NULL,'218 Đường số 3, Quận 5, TP.HCM',NULL,32940.000772476196,'BANK_TRANSFER'),('O0021','C011','PENDING','2024-10-02 14:06:47',NULL,'75 Đường số 4, Quận 11, TP.HCM',NULL,259076.59969687462,'BANK_TRANSFER'),('O0022','C053','SHIPPED','2025-02-09 14:06:47','2025-02-12 14:06:47','221 Đường số 7, Quận 4, TP.HCM',NULL,133436.80171966553,'E_WALLET'),('O0023','C007','SHIPPED','2024-07-25 14:06:47','2024-07-31 14:06:47','15 Đường số 7, Quận 4, TP.HCM',NULL,58816.00105047225,'COD'),('O0024','C012','SHIPPED','2024-10-26 14:06:47','2024-11-02 14:06:47','70 Đường số 1, Quận 3, TP.HCM',NULL,1029600.0002324581,'E_WALLET'),('O0025','C063','CANCELLED','2024-12-13 14:06:47',NULL,'87 Đường số 1, Quận 7, TP.HCM',NULL,64220.00045329332,'COD'),('O0026','C074','SHIPPED','2024-12-22 14:06:47','2024-12-28 14:06:47','91 Đường số 8, Quận 1, TP.HCM',NULL,178868.3980733156,'COD'),('O0027','C066','PENDING','2024-07-23 14:06:47',NULL,'247 Đường số 6, Quận 2, TP.HCM',NULL,31402.5,'CREDIT_CARD'),('O0028','C008','PROCESSING','2024-08-25 14:06:47',NULL,'192 Đường số 8, Quận 2, TP.HCM',NULL,88737.59888648988,'BANK_TRANSFER'),('O0029','C026','CANCELLED','2024-05-07 14:06:47',NULL,'8 Đường số 10, Quận 11, TP.HCM',NULL,404599.99310970306,'COD'),('O0030','C023','CANCELLED','2024-06-03 14:06:47',NULL,'194 Đường số 1, Quận 8, TP.HCM',NULL,141119.99859809878,'CREDIT_CARD'),('O0031','C088','PENDING','2025-04-25 14:06:47',NULL,'243 Đường số 3, Quận 4, TP.HCM',NULL,221191.20008647442,'E_WALLET'),('O0032','C010','CANCELLED','2025-01-22 14:06:47',NULL,'213 Đường số 5, Quận 2, TP.HCM',NULL,171564.00387883186,'BANK_TRANSFER'),('O0033','C068','CONFIRMED','2024-07-18 14:06:47',NULL,'244 Đường số 6, Quận 6, TP.HCM',NULL,327411.4471921027,'COD'),('O0034','C058','CANCELLED','2024-10-15 14:06:47',NULL,'100 Đường số 6, Quận 9, TP.HCM',NULL,184800.0007867813,'BANK_TRANSFER'),('O0035','C076','CONFIRMED','2024-06-01 14:06:47',NULL,'212 Đường số 1, Quận 3, TP.HCM',NULL,1585937.253474355,'COD'),('O0036','C001','SHIPPED','2024-10-02 14:06:47','2024-10-06 14:06:47','213 Đường số 6, Quận 2, TP.HCM',NULL,272859.15253586177,'COD'),('O0037','C014','SHIPPED','2024-11-17 14:06:47','2024-11-23 14:06:47','173 Đường số 9, Quận 11, TP.HCM',NULL,226462.50531077385,'E_WALLET'),('O0038','C074','PROCESSING','2025-01-21 14:06:47',NULL,'223 Đường số 9, Quận 5, TP.HCM',NULL,178002.0040243864,'CREDIT_CARD'),('O0039','C089','SHIPPED','2025-02-16 14:06:47','2025-02-21 14:06:47','134 Đường số 8, Quận 9, TP.HCM',NULL,371947.35358355637,'CREDIT_CARD'),('O0040','C088','CONFIRMED','2025-03-11 14:06:47',NULL,'90 Đường số 8, Quận 2, TP.HCM',NULL,201247.20004543662,'CREDIT_CARD'),('O0041','C030','PROCESSING','2024-08-13 14:06:47',NULL,'164 Đường số 6, Quận 9, TP.HCM',NULL,232463.11542773037,'CREDIT_CARD'),('O0042','C057','CANCELLED','2025-04-23 14:06:47',NULL,'194 Đường số 1, Quận 11, TP.HCM',NULL,180039.6013194323,'COD'),('O0043','C007','SHIPPED','2025-03-12 14:06:47','2025-03-16 14:06:47','109 Đường số 10, Quận 5, TP.HCM',NULL,195414.66568913998,'CREDIT_CARD'),('O0044','C076','PROCESSING','2024-07-28 14:06:47',NULL,'250 Đường số 4, Quận 9, TP.HCM',NULL,139438.99978995323,'CREDIT_CARD'),('O0045','C095','PENDING','2024-08-16 14:06:47',NULL,'124 Đường số 3, Quận 4, TP.HCM',NULL,1610717.4087917805,'BANK_TRANSFER'),('O0046','C064','CANCELLED','2025-01-29 14:06:47',NULL,'180 Đường số 4, Quận 3, TP.HCM',NULL,91300.00027827919,'BANK_TRANSFER'),('O0047','C080','PROCESSING','2024-09-30 14:06:47',NULL,'229 Đường số 8, Quận 5, TP.HCM',NULL,106646.14804864749,'CREDIT_CARD'),('O0048','C084','SHIPPED','2025-04-14 14:06:47','2025-04-20 14:06:47','64 Đường số 3, Quận 11, TP.HCM',NULL,1343998.4016272426,'BANK_TRANSFER'),('O0049','C017','SHIPPED','2024-08-25 14:06:47','2024-08-28 14:06:47','235 Đường số 7, Quận 7, TP.HCM',NULL,59459.39976632594,'CREDIT_CARD'),('O0050','C003','CANCELLED','2025-01-14 14:06:47',NULL,'6 Đường số 3, Quận 10, TP.HCM',NULL,779220.0011909008,'BANK_TRANSFER');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `check_orders_shippeddate_before_insert` BEFORE INSERT ON `orders` FOR EACH ROW BEGIN
    IF NEW.shipped_date IS NOT NULL THEN
        IF NEW.shipped_date < NEW.order_date THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Ngày giao hàng không thể trước ngày đặt hàng';
        END IF;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `check_orders_shippeddate_before_update` BEFORE UPDATE ON `orders` FOR EACH ROW BEGIN
    IF NEW.shipped_date IS NOT NULL AND NEW.shipped_date <> OLD.shipped_date THEN
        IF NEW.shipped_date < NEW.order_date THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Ngày giao hàng không thể trước ngày đặt hàng';
        END IF;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `update_product_quantity_after_update` AFTER UPDATE ON `orders` FOR EACH ROW BEGIN
	IF NEW.order_status = 'cancelled' AND OLD.order_status != 'cancelled' THEN
        UPDATE Product p
        JOIN OrderDetail od ON p.product_id = od.product_id
        SET 
            p.quantity = p.quantity + od.quantity,
            p.sold = p.sold - od.quantity
        WHERE od.order_id = NEW.order_id;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-10 10:24:24
