CREATE DATABASE  IF NOT EXISTS `ecommerce` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `ecommerce`;
-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: ecommerce
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `productreviewssummary`
--

DROP TABLE IF EXISTS `productreviewssummary`;
/*!50001 DROP VIEW IF EXISTS `productreviewssummary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `productreviewssummary` AS SELECT 
 1 AS `product_id`,
 1 AS `product_name`,
 1 AS `total_reviews`,
 1 AS `avg_rating`,
 1 AS `five_star`,
 1 AS `four_star`,
 1 AS `three_star`,
 1 AS `two_star`,
 1 AS `one_star`,
 1 AS `last_review_date`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `topsellingproducts`
--

DROP TABLE IF EXISTS `topsellingproducts`;
/*!50001 DROP VIEW IF EXISTS `topsellingproducts`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `topsellingproducts` AS SELECT 
 1 AS `product_id`,
 1 AS `product_name`,
 1 AS `price`,
 1 AS `discount`,
 1 AS `stock`,
 1 AS `total_sold`,
 1 AS `discounted_price`,
 1 AS `total_revenue`,
 1 AS `avg_rating`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `adminactivitydetail`
--

DROP TABLE IF EXISTS `adminactivitydetail`;
/*!50001 DROP VIEW IF EXISTS `adminactivitydetail`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `adminactivitydetail` AS SELECT 
 1 AS `admin_id`,
 1 AS `admin_name`,
 1 AS `activity`,
 1 AS `activity_time`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `categorysalessummary`
--

DROP TABLE IF EXISTS `categorysalessummary`;
/*!50001 DROP VIEW IF EXISTS `categorysalessummary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `categorysalessummary` AS SELECT 
 1 AS `category_name`,
 1 AS `total_quantity_sold`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `customerinfo`
--

DROP TABLE IF EXISTS `customerinfo`;
/*!50001 DROP VIEW IF EXISTS `customerinfo`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `customerinfo` AS SELECT 
 1 AS `customer_id`,
 1 AS `first_name`,
 1 AS `last_name`,
 1 AS `email`,
 1 AS `phone_number`,
 1 AS `address`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `admininfo`
--

DROP TABLE IF EXISTS `admininfo`;
/*!50001 DROP VIEW IF EXISTS `admininfo`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `admininfo` AS SELECT 
 1 AS `admin_id`,
 1 AS `first_name`,
 1 AS `last_name`,
 1 AS `email`,
 1 AS `total_activities`,
 1 AS `last_activity_time`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `customerorderhistory`
--

DROP TABLE IF EXISTS `customerorderhistory`;
/*!50001 DROP VIEW IF EXISTS `customerorderhistory`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `customerorderhistory` AS SELECT 
 1 AS `customer_id`,
 1 AS `customer_name`,
 1 AS `order_id`,
 1 AS `order_date`,
 1 AS `order_status`,
 1 AS `total_price`,
 1 AS `total_items`,
 1 AS `products`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `productreviewssummary`
--

/*!50001 DROP VIEW IF EXISTS `productreviewssummary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `productreviewssummary` AS select `p`.`product_id` AS `product_id`,`p`.`name` AS `product_name`,count(0) AS `total_reviews`,round(avg(`r`.`rating`),1) AS `avg_rating`,sum((case when (`r`.`rating` = 5) then 1 else 0 end)) AS `five_star`,sum((case when (`r`.`rating` = 4) then 1 else 0 end)) AS `four_star`,sum((case when (`r`.`rating` = 3) then 1 else 0 end)) AS `three_star`,sum((case when (`r`.`rating` = 2) then 1 else 0 end)) AS `two_star`,sum((case when (`r`.`rating` = 1) then 1 else 0 end)) AS `one_star`,max(`r`.`created_at`) AS `last_review_date` from (`product` `p` left join `review` `r` on((`p`.`product_id` = `r`.`product_id`))) group by `p`.`product_id`,`p`.`name` order by `avg_rating` desc,`total_reviews` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `topsellingproducts`
--

/*!50001 DROP VIEW IF EXISTS `topsellingproducts`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `topsellingproducts` AS select `p`.`product_id` AS `product_id`,`p`.`name` AS `product_name`,`p`.`price` AS `price`,`p`.`discount` AS `discount`,`p`.`quantity` AS `stock`,`p`.`sold` AS `total_sold`,round((`p`.`price` * (1 - ifnull(`p`.`discount`,0))),2) AS `discounted_price`,sum(((`od`.`quantity` * `od`.`unit_price`) * (1 - ifnull(`od`.`discount`,0)))) AS `total_revenue`,round(avg(`r`.`rating`),1) AS `avg_rating` from (((`product` `p` left join `orderdetail` `od` on((`p`.`product_id` = `od`.`product_id`))) left join `orders` `o` on(((`od`.`order_id` = `o`.`order_id`) and (`o`.`order_status` = 'shipped')))) left join `review` `r` on((`p`.`product_id` = `r`.`product_id`))) group by `p`.`product_id` order by `total_sold` desc,`total_revenue` desc limit 100 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `adminactivitydetail`
--

/*!50001 DROP VIEW IF EXISTS `adminactivitydetail`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `adminactivitydetail` AS select `a`.`admin_id` AS `admin_id`,concat(`a`.`first_name`,' ',`a`.`last_name`) AS `admin_name`,`al`.`activity` AS `activity`,`al`.`activity_time` AS `activity_time` from (`admin` `a` join `activitylog` `al` on((`a`.`admin_id` = `al`.`admin_id`))) order by `al`.`activity_time` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `categorysalessummary`
--

/*!50001 DROP VIEW IF EXISTS `categorysalessummary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `categorysalessummary` AS select `c`.`description` AS `category_name`,sum(`od`.`quantity`) AS `total_quantity_sold` from (((`orderdetail` `od` join `product` `p` on((`od`.`product_id` = `p`.`product_id`))) join `producthascategories` `pc` on((`p`.`product_id` = `pc`.`product_id`))) join `category` `c` on((`pc`.`category_id` = `c`.`category_id`))) group by `c`.`description` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `customerinfo`
--

/*!50001 DROP VIEW IF EXISTS `customerinfo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `customerinfo` AS select `customer`.`customer_id` AS `customer_id`,`customer`.`first_name` AS `first_name`,`customer`.`last_name` AS `last_name`,`customer`.`email` AS `email`,`customer`.`phone_number` AS `phone_number`,`customer`.`address` AS `address` from `customer` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `admininfo`
--

/*!50001 DROP VIEW IF EXISTS `admininfo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `admininfo` AS select `a`.`admin_id` AS `admin_id`,`a`.`first_name` AS `first_name`,`a`.`last_name` AS `last_name`,`a`.`email` AS `email`,count(`al`.`activity`) AS `total_activities`,max(`al`.`activity_time`) AS `last_activity_time` from (`admin` `a` left join `activitylog` `al` on((`a`.`admin_id` = `al`.`admin_id`))) group by `a`.`admin_id`,`a`.`first_name`,`a`.`last_name`,`a`.`email` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `customerorderhistory`
--

/*!50001 DROP VIEW IF EXISTS `customerorderhistory`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `customerorderhistory` AS select `c`.`customer_id` AS `customer_id`,concat(`c`.`first_name`,' ',`c`.`last_name`) AS `customer_name`,`o`.`order_id` AS `order_id`,`o`.`order_date` AS `order_date`,`o`.`order_status` AS `order_status`,`o`.`total_price` AS `total_price`,count(`od`.`product_id`) AS `total_items`,group_concat(`p`.`name` separator ', ') AS `products` from (((`customer` `c` join `orders` `o` on((`c`.`customer_id` = `o`.`customer_id`))) join `orderdetail` `od` on((`o`.`order_id` = `od`.`order_id`))) join `product` `p` on((`od`.`product_id` = `p`.`product_id`))) where (`o`.`order_status` in ('pending','confirm','processing','shipped','cancelled')) group by `o`.`order_id`,`c`.`customer_id`,`c`.`first_name`,`c`.`last_name`,`o`.`order_date`,`o`.`order_status`,`o`.`total_price` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping routines for database 'ecommerce'
--
/*!50003 DROP PROCEDURE IF EXISTS `GetRevenueReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetRevenueReport`(IN start_date DATE, IN end_date DATE)
BEGIN
	SELECT DATE(order_date) AS order_day, COUNT(*) AS total_orders, SUM(total_price) AS total_revenue, AVG(total_price) AS avg_order_value
    FROM Orders
    WHERE order_date BETWEEN start_date AND end_date
    AND order_status NOT IN ('cancelled', 'pending')
    GROUP BY DATE(order_date)
    ORDER BY order_day;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetSalesReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetSalesReport`(IN start_date DATE, IN end_date DATE, IN p_category_id VARCHAR(50))
BEGIN
    SELECT p.product_id, p.name, c.description AS category, SUM(od.quantity) AS total_sold, SUM(od.quantity * od.unit_price * (1 - IFNULL(od.discount, 0))) AS total_revenue
    FROM OrderDetail od JOIN Orders o ON od.order_id = o.order_id
		JOIN Product p ON od.product_id = p.product_id
		LEFT JOIN ProductHasCategories phc ON p.product_id = phc.product_id
		LEFT JOIN Category c ON phc.category_id = c.category_id
    WHERE o.order_date BETWEEN start_date AND end_date AND o.order_status = 'shipped' AND (p_category_id IS NULL OR phc.category_id = p_category_id)
    GROUP BY p.product_id
    ORDER BY total_revenue DESC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ProcessOrder` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ProcessOrder`(IN p_order_id VARCHAR(50), IN new_status VARCHAR(50))
BEGIN
    DECLARE current_status VARCHAR(50);
    DECLARE order_exists INT;
    DECLARE is_valid_transition BOOLEAN DEFAULT FALSE;
    
    SELECT COUNT(*) INTO order_exists FROM Orders WHERE order_id = p_order_id;
    IF order_exists = 0 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Đơn hàng không tồn tại';
    END IF;
    
    SELECT order_status INTO current_status 
    FROM Orders 
    WHERE order_id = p_order_id;
    
    IF current_status = 'cancelled' THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Không thể thay đổi trạng thái đơn hàng đã hủy';
    END IF;
    
    IF current_status = 'shipped' THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Không thể thay đổi trạng thái đơn hàng đã hoàn thành';
    END IF;
    
    CASE 
        WHEN current_status = 'pending' AND new_status = 'confirmed' THEN
            SET is_valid_transition = TRUE;
            
        WHEN current_status = 'confirmed' AND new_status = 'processing' THEN
            SET is_valid_transition = TRUE;
            
        WHEN current_status = 'processing' AND new_status = 'shipped' THEN
            SET is_valid_transition = TRUE;
        ELSE
            SET is_valid_transition = FALSE;
    END CASE;
    
    IF NOT is_valid_transition THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Chuyển trạng thái không hợp lệ';
    END IF;
    IF new_status = 'shipped' THEN
		UPDATE Orders
        SET shipped_date = NOW()
        WHERE order_id = p_order_id;
	END IF;
    
    UPDATE Orders 
    SET order_status = new_status
    WHERE order_id = p_order_id;
    
    SELECT CONCAT('Đã cập nhật đơn hàng ', p_order_id, ' từ ', current_status, ' sang ', new_status) AS message;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `TableToCSV` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `TableToCSV`(IN p_table_name VARCHAR(255), IN p_file_path VARCHAR(255), IN p_delimiter VARCHAR(10))
BEGIN
    DECLARE v_table_exists INT DEFAULT 0;
    
    SELECT COUNT(*) INTO v_table_exists 
    FROM information_schema.tables 
    WHERE table_schema = DATABASE() AND table_name = p_table_name;
    
    IF v_table_exists = 0 THEN
		SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Bảng không tồn tại';
    END IF;
    
    SET @sql = CONCAT(
        "SELECT * FROM ", p_table_name,
        " INTO OUTFILE '", p_file_path,
        "' FIELDS TERMINATED BY '", p_delimiter, "'",
        " ENCLOSED BY '\"'",
        " LINES TERMINATED BY '\n'"
    );
    
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
    SELECT CONCAT('Đã backup bảng ', p_table_name, ' ra file: ', p_file_path) AS result;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdateInventory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateInventory`(IN p_product_id VARCHAR(50), IN quantity_change INT, IN is_increase BOOLEAN)
BEGIN
	DECLARE current_qty INT;
    
    IF is_increase THEN
        UPDATE Product 
        SET quantity = quantity + quantity_change
        WHERE product_id = p_product_id;
	ELSE
        SELECT quantity INTO current_qty 
        FROM Product 
        WHERE product_id = p_product_id;
        
        IF current_qty < quantity_change THEN
            SIGNAL SQLSTATE '45000' 
            SET MESSAGE_TEXT = 'Số lượng tồn kho không đủ';
        ELSE
            UPDATE Product 
            SET quantity = quantity - quantity_change
            WHERE product_id = p_product_id;
        END IF;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ValidatePassword` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ValidatePassword`(INOUT p_password VARCHAR(255))
BEGIN
    DECLARE is_valid BOOLEAN DEFAULT TRUE;
    DECLARE error_message VARCHAR(255) DEFAULT '';

    IF LENGTH(p_password) < 8 THEN
        SET is_valid = FALSE;
        SET error_message = CONCAT(error_message, 'Mật khẩu phải có ít nhất 8 ký tự. ');
    END IF;

    IF p_password NOT REGEXP '[0-9]' THEN
        SET is_valid = FALSE;
        SET error_message = CONCAT(error_message, 'Mật khẩu phải chứa ít nhất 1 số. ');
    END IF;

    IF p_password NOT REGEXP '[A-Za-z]' THEN
        SET is_valid = FALSE;
        SET error_message = CONCAT(error_message, 'Mật khẩu phải chứa ít nhất 1 chữ cái. ');
    END IF;

    IF p_password NOT REGEXP '[!@#$%^&*(),.?":{}|<>]' THEN
        SET is_valid = FALSE;
        SET error_message = CONCAT(error_message, 'Mật khẩu phải chứa ít nhất 1 ký tự đặc biệt. ');
    END IF;

    IF NOT is_valid THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = error_message;
    END IF;

    SET p_password = SHA2(p_password, 256);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-10 10:24:25
